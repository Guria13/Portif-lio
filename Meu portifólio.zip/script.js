// Efeito 1: trocar cor de fundo na página inicial
document.addEventListener('DOMContentLoaded', () => {
  const botaoTrocar = document.getElementById('trocarCor');
  if (botaoTrocar) {
    botaoTrocar.addEventListener('click', () => {
      document.body.style.backgroundColor =
        document.body.style.backgroundColor === 'lavender' ? '#f8f4ff' : 'lavender';
    });
  }

  // Efeito 2: Validação simples do formulário de contato
  const contatoForm = document.getElementById('contatoForm');
  if (contatoForm) {
    contatoForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const nome = document.getElementById('nome');
      const email = document.getElementById('email');
      const mensagem = document.getElementById('mensagem');

      if (!nome.value.trim() || !email.value.trim() || !mensagem.value.trim()) {
        alert('Por favor, preencha todos os campos!');
        return;
      }

      // Simula envio — aqui você poderia integrar a uma API ou serviço de e‑mail
      alert('Mensagem enviada com sucesso! Obrigada pelo contato, ' + nome.value + ' 😊');
      contatoForm.reset();
    });
  }

  // Saudação automática
  alert('Olá! Bem‑vindo(a) ao meu portfólio. 😊');
});
